# Frontend — PRAVAAH-NOW Dashboard

Built with v0.dev (React + Tailwind CSS). Live map, layer toggles
(Doppler Z / Wind Shear / DEM Slope), 0–6hr nowcast timeline scrubber,
ward-level alert sidebar, and CAP/SACHET dispatch trigger.

## How this folder gets filled in

From your v0.dev project: use the **"Push to GitHub"** option in the
v0 UI (top-right of the project view) and point it at this repo/folder
— it will commit the generated React project directly, no manual
copy-paste needed.

If you'd rather export manually instead:
1. In v0, click **Download ZIP** (or the `...` menu → Export).
2. Unzip its contents directly into this `frontend/` folder, replacing
   this README (or keeping it — just add the real project files
   alongside it).
3. From `frontend/`, run `npm install && npm run dev` to confirm it
   still runs after the move.

## Wiring to the real backend

The dashboard currently uses its own internal mock data. To point it
at `../backend` instead:

```js
// wherever the dashboard fetches its forecast state:
const res = await fetch("http://localhost:8000/nowcast", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ lead_time_minutes: selectedLeadTime }),
});
const data = await res.json();
```

And for the dispatch button:

```js
const res = await fetch("http://localhost:8000/dispatch-alert", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    cell_id: "A1",
    lead_time_minutes: selectedLeadTime,
    peak_dbz: peakReflectivity,
    rain_rate_mm_hr: instantRainRate,
  }),
});
```

The backend's response shape (`backend/main.py`) matches the fields
your alert card, gauges, and ward list already expect.
